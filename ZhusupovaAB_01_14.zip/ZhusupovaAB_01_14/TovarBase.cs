﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZhusupovaAB_01_14
{
    public class TovarBase
    {
        public string Name; //Переменная с именем товара
        public int Price; // Переменная с ценой товара
        public int Count; //Переменная с количеством товара
        public int Q; //Переменная для подсчета значения Q по заданнной формуле

        public TovarBase(string name, int price, int count) //Конструктор базового класса
        {
            Name = name;
            Price = price;
            Count = count;
            Calculation();
        }

        public virtual int Calculation() //Метод для подсчета переменной Q по заданной формуле
        {
            Q = Price / Count;
            return Q;
        }

        public virtual string PrintInfo() //Метод для вывода информации
        {
            return $"Наименование - {Name}\nЦена - {Price}\nКоличество - {Count}\nQ - {Q}";
        }
    }
}
