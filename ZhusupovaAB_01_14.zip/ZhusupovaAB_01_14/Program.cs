﻿using System;

namespace ZhusupovaAB_01_14
{
    class Program
    {
        static void Main (string[] args)
        {
            TovarBase tovarBase = new TovarBase("Карандаш", 648, 10); //создание экземпляра базового класса
            //tovarBase.Calculation(); //Подсчет Q по заданной формуле
            Console.WriteLine(tovarBase.PrintInfo()); //вывод информации

            Console.WriteLine("----------------------------------------------");

            TovarChild tovarChild = new TovarChild("Тетрадь", 150, 15, 2013); // Создание экземпляра дочернего класса
            //tovarChild.Calculation(); //Подсчет Qp по заданной формуле
            Console.WriteLine(tovarChild.PrintInfo()); //вывод информации
        }
    }
}
