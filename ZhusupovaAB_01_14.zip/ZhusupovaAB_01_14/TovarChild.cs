﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZhusupovaAB_01_14
{
    public class TovarChild: TovarBase
    {
        public int P; //Переменная для года выпуска товара
        public int Qp;
        public int T = DateTime.Now.Year; // Переменная с текущим годом

        public TovarChild(string name, int price, int count, int p) : base(name, price, count) //Конструктор производного класса
        {
            P = p;
            Calculation();
        }

        public override int Calculation () //Переопределяющий метод производного класса, рассчитывающий переменную по новой формуле
        {
            return Qp = (int) (base.Calculation() + 0.5 * (T - P));
        }

        public override string PrintInfo() //Метод для вывода информации
        {
            return $"Наименование - {Name}\nЦена - {Price}\nКоличество - {Count}\nQp - {Qp}";
        }
    }
}
